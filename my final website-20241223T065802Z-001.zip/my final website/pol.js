function navigate() {
    var select = document.getElementById("product");
    var selectedOption = select.options[select.selectedIndex].value;
    if (selectedOption != "select") {
        window.location.href = selectedOption;
    }
}