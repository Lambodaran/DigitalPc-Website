function addToCart(productName, price, imageUrl) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push({ productName, price, imageUrl });
    localStorage.setItem('cart', JSON.stringify(cart));
    alert('Product added to cart');
}

// Update the buttons to include the image URL as an argument when calling addToCart
document.querySelectorAll('.grid-item').forEach(item => {
    item.querySelector('button').addEventListener('click', () => {
        const productName = item.querySelector('p').textContent;
        const priceText = item.querySelector('#rs').textContent;
        const price = parseFloat(priceText.replace('RS ', '').replace(/,/g, ''));
        const imageUrl = item.querySelector('img').src;
        addToCart(productName, price, imageUrl);
    });
});


function navigate() {
    var select = document.getElementById("product");
    var selectedOption = select.options[select.selectedIndex].value;
    if (selectedOption != "select") {
        window.location.href = selectedOption;
    }
}
