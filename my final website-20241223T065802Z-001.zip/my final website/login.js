function login() {
    // Add login functionality here
    alert("Login button clicked!");
  }
  
  function register() {
    // Redirect to the register page
    window.location.href = "register.html";
  }

  function navigate() {
    var select = document.getElementById("product");
    var selectedOption = select.options[select.selectedIndex].value;
    if (selectedOption != "select") {
        window.location.href = selectedOption;
    }
}
  