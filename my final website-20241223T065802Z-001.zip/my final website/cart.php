<?php
if (!isset($_SESSION['username'])){
    header("loaction: login.html");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Shopping Cart</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <style>
    ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    background-color: #333;
    overflow: hidden;
    }

    li {
        float: left;
    }

    li a {
        display: block;
        color: white;
        padding: 14px 16px;
        text-decoration: none;
    }

    li a:hover {
        background-color: #111;
    }
    .menu{
        margin-left: 1000px;
    }

    #product{
        background-color: #333;
        border: 0px;
        margin-top: 15px;
        color: #ffffff;
    }

    #img{
        width: 10%;
        height: auto;
        margin-right: 10px;
        float: left;
    }

    #copyright{
    text-align: center;
    margin-top: 450px;
    padding-top: 0px;
    color: #ffffff;
    background-color: #424141;
    height: 70px;
    width: 1300px;
    width: 100%;
}
   </style>

    <script>
        function loadCart() {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            let cartItemsContainer = document.getElementById('cart-items');
            let totalPriceElement = document.getElementById('total-price');
            
            // Clear previous cart items
            cartItemsContainer.innerHTML = '';
            let totalPrice = 0;

            if (cart.length === 0) {
                cartItemsContainer.innerHTML = '<p>Your cart is empty.</p>';
            } else {
                cart.forEach(item => {
                    totalPrice += item.price;
                    let itemElement = document.createElement('div');
                    itemElement.classList.add('cart-item');
                    itemElement.innerHTML = `
                        <img src="${item.imageUrl}" alt="${item.productName}" style="width:100px;height:100px;">
                        <p><strong>Product:</strong> ${item.productName}</p>
                        <p><strong>Price:</strong> RS ${item.price.toFixed(2)}</p>
                    `;
                    cartItemsContainer.appendChild(itemElement);
                });
            }

            // Display the total price
            totalPriceElement.innerHTML = 'Total Price: RS ' + totalPrice.toFixed(2);
        }

        function clearCart() {
            localStorage.removeItem('cart');
            loadCart();
            alert("Cart has been cleared!");
        }

        window.onload = loadCart;

        function navigate() {
    var select = document.getElementById("product");
    var selectedOption = select.options[select.selectedIndex].value;
    if (selectedOption != "select") {
        window.location.href = selectedOption;
    }
    }
    </script>
</head>
<body>
        <ul>
            <li><a href="login.html"><img src="login.png" id="img"></a></li>
            <div class="menu">
            <li><a href="digital pc.html">home</a></li>

            <li>  
                <label for="product"></label>
                <select id="product" name="product" onchange="navigate()">
                    <option value="select">Select a product</option>
                    <option value="desktop.html">Desktop</option>
                    <option value="laptop.html">Laptop</option>
                    <option value="accessory.html">Accessories</option>
                    <option value="all in one pc.html">All-in-One PC</option>
                </select>
            </li>

            <li><a href="contact.html">contact</a></li>
            <li><a href="cart.php">view cart</a></li>
            </div>
        </ul>
    <br>

    <div class="cart-container">
        <h1>Your Shopping Cart</h1>
        <div id="cart-items"></div>
        <div id="total-price"></div>
        <button onclick="clearCart()">Clear Cart</button>
    </div>

    <footer id="copyright">
        <p>&copy; 2024 Digital Pc. All rights reserved.</p>
    </footer>
</body>
</html>

