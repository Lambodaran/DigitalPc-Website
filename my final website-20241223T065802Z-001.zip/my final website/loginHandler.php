<?php
session_start();
$servername = "localhost"; // Replace with your server name
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "login"; // Replace with your database name
 
 
$conn = new mysqli($servername, $username, $password, $dbname);
 
 
 
 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uname = $_POST['username'];
    $password = $_POST['password'];
 

 
    $result = $conn->query("select * from users where username='$uname' and password='$password'");
 
 
    if ($result->num_rows > 0) {
       $_SESSION['username'] = $uname;
        header("Location: digital pc.html?user=$uname");
    } else {
        echo "wrong password";
    }
 
   
}
?>
 
 
